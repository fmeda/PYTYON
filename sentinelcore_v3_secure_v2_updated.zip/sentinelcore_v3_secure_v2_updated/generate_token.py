from cryptography.fernet import Fernet

def generate_encrypted_token(token_plaintext: str):
    key = Fernet.generate_key()
    fernet = Fernet(key)
    encrypted_token = fernet.encrypt(token_plaintext.encode())
    print(f"Encryption key (set as SENTINEL_ENCRYPTION_KEY): {key.decode()}")
    print(f"Encrypted token (set as SENTINEL_ENC_TOKEN): {encrypted_token.decode()}")

if __name__ == "__main__":
    generate_encrypted_token("MASTER-KEY-1234")
