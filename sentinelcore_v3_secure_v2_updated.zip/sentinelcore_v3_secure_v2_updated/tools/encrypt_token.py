from cryptography.fernet import Fernet

def encrypt_token(key_str: str, token_plain: str):
    key_bytes = key_str.encode()
    f = Fernet(key_bytes)
    encrypted_token = f.encrypt(token_plain.encode())
    print("Token criptografado (copie e use em SENTINEL_ENC_TOKEN):")
    print(encrypted_token.decode())

if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("Uso: python encrypt_token.py <fernet_key> <token_plain>")
        print("Exemplo: python encrypt_token.py 1eH3dNcB3qSOpVeB9Z6G7REHc2flAoMlLZmpTOsQbRw= meu_token")
        sys.exit(1)

    key = sys.argv[1]
    token = sys.argv[2]

    encrypt_token(key, token)
