# SentinelCore v3 Secure - Manual de Uso (HELP)

---

## 1. Introdução

SentinelCore v3 Secure é uma solução híbrida de Endpoint Detection and Response (EDR), com núcleo em Rust para coleta segura e eficiente de eventos, e interface Python para visualização, alertas e integração com SIEM. 

Esta ferramenta oferece recursos ofensivos e defensivos aliados à automação e análise para ambientes Windows, Linux e cloud.

---

## 2. Pré-requisitos

- Python 3.8+
- Rust instalado (opcional para desenvolvimento do core)
- Dependências Python instaladas via:

```bash
python interface/bootstrap.py
