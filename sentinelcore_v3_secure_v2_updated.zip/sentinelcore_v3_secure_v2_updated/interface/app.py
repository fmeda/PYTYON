from fastapi import FastAPI, Depends
from fastapi.security import OAuth2PasswordBearer
from interface.api.routes import router as api_router
from interface.api.dependencies import verify_token
from interface.infrastructure.database import init_db

app = FastAPI(title="SentinelCore API", version="v3")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")

@app.on_event("startup")
async def startup():
    init_db()

@app.get("/status")
async def read_status(token: str = Depends(verify_token)):
    return {"status": "SentinelCore API is running securely"}

app.include_router(api_router, prefix="/api", dependencies=[Depends(verify_token)])
