def execute_response(event_id: int, action: str):
    print(f"Responding to event {event_id} with action {action}")
