import subprocess

def invoke_rust_agent(mode: str, target: str):
    result = subprocess.run(["./core/target/debug/sentinel_agent", mode, target], capture_output=True, text=True)
    return result.stdout
