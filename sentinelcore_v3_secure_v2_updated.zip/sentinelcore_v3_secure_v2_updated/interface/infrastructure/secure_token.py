import os
from cryptography.fernet import Fernet

class SecureTokenManager:
    def __init__(self):
        self.encrypted_token = os.getenv("SENTINEL_ENC_TOKEN")
        self.encryption_key = os.getenv("SENTINEL_ENCRYPTION_KEY")
        if not self.encrypted_token or not self.encryption_key:
            raise EnvironmentError("Missing encrypted token or encryption key in environment variables.")
        self.fernet = Fernet(self.encryption_key.encode())

    def get_token(self):
        decrypted = self.fernet.decrypt(self.encrypted_token.encode())
        return decrypted.decode()
