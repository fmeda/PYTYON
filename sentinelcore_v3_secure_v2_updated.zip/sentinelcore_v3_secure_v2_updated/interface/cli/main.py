# interface/cli/main.py

import sys
import os

# Ajusta sys.path para permitir importações do pacote interface
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from dotenv import load_dotenv
load_dotenv()  # Carrega variáveis de ambiente do arquivo .env

import typer
from interface.infrastructure.secure_token import SecureTokenManager

app = typer.Typer()

def initialize_token_manager():
    try:
        return SecureTokenManager()
    except OSError as ose:
        if "Missing encrypted token or encryption key" in str(ose):
            typer.secho(
                "[Erro Técnico] Variáveis de ambiente obrigatórias ausentes.\n"
                "Por favor, configure no arquivo '.env':\n"
                "  SENTINEL_ENCRYPTION_KEY=<sua_chave_fernet_aqui>\n"
                "  SENTINEL_ENC_TOKEN=<seu_token_criptografado_aqui>\n",
                fg=typer.colors.RED,
                err=True
            )
            sys.exit(1)
        else:
            raise ose
    except ValueError as ve:
        if "Fernet key must be 32 url-safe base64-encoded bytes" in str(ve):
            typer.secho(
                "[Erro Técnico] Chave Fernet inválida.\n"
                "A chave deve ser uma string base64 url-safe de 44 caracteres.\n"
                "Use o script 'generate_fernet_key.py' para gerar uma chave válida.\n",
                fg=typer.colors.RED,
                err=True
            )
            sys.exit(1)
        else:
            raise ve

token_manager = initialize_token_manager()

@app.command()
def scan(target: str, mode: str = "deep"):
    """Executa varredura no alvo especificado."""
    typer.echo(f"Executando scan em {target} com modo {mode}")
    # Aqui pode-se adicionar a lógica real de varredura usando token_manager

if __name__ == "__main__":
    app()
