from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class Incident(BaseModel):
    title: str
    description: str
    severity: str

@router.post("/incident")
async def create_incident(incident: Incident):
    return {"message": "Incident created", "incident": incident}

class Alert(BaseModel):
    host: str
    indicator: str
    confidence: float

@router.post("/alert")
async def receive_alert(alert: Alert):
    return {"message": "Alert received", "alert": alert}
