from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from interface.infrastructure.secure_token import SecureTokenManager

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")
token_manager = SecureTokenManager()

async def verify_token(token: str = Depends(oauth2_scheme)):
    try:
        expected_token = token_manager.get_token()
        if token != expected_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication setup error",
            headers={"WWW-Authenticate": "Bearer"},
        )
