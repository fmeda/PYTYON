import importlib.util
import subprocess
import sys

REQUIRED_MODULES = {
    "fastapi": "0.95.0",
    "uvicorn": "0.22.0",
    "typer": "0.9.0",
    "rich": "13.3.1",
    "pydantic": "1.10.11",
    "sqlalchemy": "2.0.19",
    "cryptography": "41.0.3",
}

def install_package(package: str, version: str):
    """Instala o pacote via pip."""
    print(f"[+] Instalando: {package}>={version}")
    subprocess.check_call([sys.executable, "-m", "pip", "install", f"{package}>={version}"])

def check_and_install_modules():
    print("[*] Verificando dependências...")
    for module, min_version in REQUIRED_MODULES.items():
        if importlib.util.find_spec(module) is None:
            print(f"[!] Módulo {module} não encontrado.")
            install_package(module, min_version)
        else:
            print(f"[OK] {module} já está instalado.")

    print("[✔] Todos os módulos verificados.")

if __name__ == "__main__":
    check_and_install_modules()
