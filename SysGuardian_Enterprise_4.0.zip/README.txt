SysGuardian Enterprise 4.0
Instruções rápidas:
1. Extrair ZIP em C:\Scripts\SysGuardian
2. Set-ExecutionPolicy RemoteSigned -Scope LocalMachine
3. Executar script manualmente ou via Task Scheduler
4. Verificar logs e notificações