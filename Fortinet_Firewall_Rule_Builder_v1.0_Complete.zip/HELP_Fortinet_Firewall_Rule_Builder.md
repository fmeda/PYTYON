# Fortinet FortiGate Firewall Rule Builder v1.0

## Objetivo
Ferramenta CLI interativa em Python 3 para gerar **rascunhos offline** de políticas IPv4 para FortiGate/FortiOS. **Não se conecta ao firewall e não faz deploy.**

## Requisitos e execução
Python 3.9+; sem bibliotecas externas. Windows PowerShell: `py .\fortinet_firewall_rule_builder.py`. Linux: `python3 fortinet_firewall_rule_builder.py`.

## Passo a passo
1. Informe modelo, versão FortiOS, GMUD, nome e justificativa.
2. Informe IPs/redes de origem e destino (IPv4/CIDR), interfaces ou zonas conforme configuração real da VDOM.
3. Selecione TCP/UDP, porta de destino (1–65535), `accept` ou `deny`, NAT e logging.
4. Escolha nomes únicos para objetos de endereços e serviço customizado.
5. Confira a prévia. Confirme para salvar `.cli` e `.json` em `firewall_rules/`.
6. **Antes de aplicar**, valide em laboratório e siga o processo de Change Management.

## Exemplo
- Origem: `10.10.10.0/24`; destino: `172.16.20.10/32`.
- Origem `port2`, destino `port3`; TCP/443; ação `accept`; NAT `disable`; logging `all`.
- A saída contém `config firewall address`, `config firewall service custom` e `config firewall policy`.

## Limitações e verificações críticas
- Apenas políticas IPv4 com TCP ou UDP e uma porta de destino. Não gera políticas IPv6, VIP/DNAT, grupos, endereços FQDN, ISDB, identidade, inspeção SSL, políticas por aplicação ou perfis UTM.
- `edit 0` cria uma nova política com ID atribuído pelo FortiOS; **verifique a posição e precedência** antes de ativar. Uma regra anterior pode prevalecer.
- **Nomes já existentes podem ser alterados** pelo comando `edit`; confira os objetos e faça backup. O gerador não consulta o equipamento.
- O campo NAT corresponde a SNAT por política; em ambientes com **central NAT**, o tratamento é diferente e deve ser revisado.
- Interface e zona devem existir na VDOM correta. Roteamento, SD-WAN, VIPs, NAT e perfis de segurança exigem validação separada.
- O campo de versão é informativo: **o programa não verifica compatibilidade por modelo ou release**.
- Para ambientes FortiManager, siga o fluxo de política/ADOM e instalação correspondente; não aplique o bloco diretamente sem planejamento.
- O arquivo `.cli` é um rascunho para revisão, não uma configuração garantida para produção.

## WARNING OBRIGATÓRIO
**SALVAR BASELINE E BACKUP antes da MUDANÇA.**

Verifique configuração atual, objetos existentes, ordem das políticas, VDOM, NAT, roteamento, interfaces, logging, aprovação da GMUD, janela, testes e plano de rollback.

## Comandos de consulta úteis (somente leitura)
```
get system status
show firewall policy
show firewall address
show firewall service custom
get router info routing-table all
```
Confirme a VDOM e os privilégios antes de executar qualquer comando.
