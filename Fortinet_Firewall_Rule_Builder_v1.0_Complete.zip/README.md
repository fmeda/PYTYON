# Fortinet FortiGate Firewall Rule Builder

Execute `python3 fortinet_firewall_rule_builder.py` (ou `py .\fortinet_firewall_rule_builder.py` no Windows).

Leia `HELP_Fortinet_Firewall_Rule_Builder.md` antes de usar.

**SALVAR BASELINE E BACKUP antes da MUDANÇA.** Nenhuma configuração é aplicada automaticamente.
