#!/usr/bin/env python3
"""Fortinet FortiGate Firewall Policy Builder v1.0 — offline generator."""
import datetime as dt
import ipaddress
import json
import re
from pathlib import Path

OUT = Path(__file__).resolve().parent / 'firewall_rules'


def ask(label, default=None, required=True):
    while True:
        prompt = f'{label}' + (f' [{default}]' if default is not None else '') + ': '
        value = input(prompt).strip() or (default if default is not None else '')
        if value or not required:
            return value
        print('  Campo obrigatório.')


def choice(label, options, default):
    while True:
        val = ask(f'{label} ({"/".join(options)})', default).lower()
        if val in options:
            return val
        print('  Escolha uma opção válida.')


def name(label, default=None):
    while True:
        value = ask(label, default)
        if re.fullmatch(r'[A-Za-z0-9_.-]{1,63}', value):
            return value
        print('  Use 1–63 caracteres: letras, números, ponto, hífen ou underscore.')


def iface(label):
    # FortiOS interface names may contain spaces; quote safely and exclude CLI control characters.
    while True:
        value = ask(label)
        if len(value) <= 63 and not any(c in value for c in '\r\n"\\') and all(ord(c) >= 32 for c in value):
            return value
        print('  Interface inválida: não use aspas, barras invertidas ou controles.')


def network(label):
    while True:
        value = ask(label)
        try:
            net = ipaddress.ip_network(value, strict=False)
            if net.version != 4:
                raise ValueError('IPv6 não suportado nesta versão')
            return net
        except ValueError as e:
            print(f'  IPv4/CIDR inválido: {e}')


def port(label):
    while True:
        value = ask(label)
        if re.fullmatch(r'\d{1,5}', value) and 1 <= int(value) <= 65535:
            return int(value)
        print('  Informe porta TCP/UDP entre 1 e 65535.')


def safe_comment(s):
    # No user-controlled newlines, quotes or backslashes in CLI strings.
    return re.sub(r'[^A-Za-z0-9 À-ÿ_.,:;()/#-]', ' ', s)[:240]


def build(rule):
    src = ipaddress.ip_network(rule['src'], strict=False)
    dst = ipaddress.ip_network(rule['dst'], strict=False)
    src_mask = str(src.netmask)
    dst_mask = str(dst.netmask)
    service = rule['service_name']
    lines = [
        '# FORTINET FORTIGATE - POLICY GENERATOR (OFFLINE)',
        f'# Change ID: {rule["change_id"]} | FortiOS: {rule["version"]} | Model: {rule["model"]}',
        '# REVIEW BEFORE APPLYING. NOT DEPLOYED AUTOMATICALLY.',
        '# Ensure VDOM is selected correctly; review objects, policy order and NAT.',
        'config firewall address',
        f'    edit "{rule["src_object"]}"',
        f'        set subnet {src.network_address} {src_mask}',
        '    next',
        f'    edit "{rule["dst_object"]}"',
        f'        set subnet {dst.network_address} {dst_mask}',
        '    next',
        'end',
        'config firewall service custom',
        f'    edit "{service}"',
        f'        set {rule["protocol"].lower()}-portrange {rule["dst_port"]}',
        '    next',
        'end',
        'config firewall policy',
        '    edit 0',
        f'        set name "{rule["policy_name"]}"',
        f'        set srcintf "{rule["srcintf"]}"',
        f'        set dstintf "{rule["dstintf"]}"',
        f'        set srcaddr "{rule["src_object"]}"',
        f'        set dstaddr "{rule["dst_object"]}"',
        f'        set action {rule["action"]}',
        '        set schedule "always"',
        f'        set service "{service}"',
        f'        set logtraffic {rule["logtraffic"]}',
        f'        set comments "{safe_comment(rule["change_id"] + " " + rule["description"])}"',
    ]
    if rule['action'] == 'accept':
        lines.append(f'        set nat {rule["nat"]}')
    lines += ['    next', 'end',
              '# WARNING: edit 0 creates a policy; verify its assigned ID and position.',
              '# WARNING: Existing objects with identical names may be modified.',
              '# WARNING: Confirm routing, SD-WAN, VDOM, security profiles and implicit deny.',
              '# SALVAR BASELINE E BACKUP antes da MUDANÇA']
    return '\n'.join(lines) + '\n'


def collect():
    print('\n' + '=' * 65)
    print(' FORTINET FORTIGATE FIREWALL RULE BUILDER v1.0')
    print(' Gerador offline de políticas FortiOS IPv4 - SEM deploy')
    print('=' * 65)
    print('ATENÇÃO: FortiManager e FortiOS podem exigir workflows diferentes.')
    model = name('Modelo (ex.: FG-100F)', 'FG-100F')
    version = ask('Versão FortiOS (ex.: 7.4.x)', '7.4.x')
    change_id = name('ID da GMUD', 'CHG-2026-001')
    policy_name = name('Nome da política', 'ALLOW_APP_HTTPS')
    description = ask('Descrição/justificativa', 'Permitir HTTPS para aplicação')
    print('\n[1/3] Redes e interfaces (confirme a VDOM correta)')
    src = network('Rede/IP origem (ex.: 10.10.10.0/24)')
    dst = network('Rede/IP destino (ex.: 172.16.20.10/32)')
    srcintf = iface('Interface/zona origem (ex.: port2 ou LAN)')
    dstintf = iface('Interface/zona destino (ex.: port3 ou DC)')
    print('\n[2/3] Serviço e política')
    protocol = choice('Protocolo', ['tcp', 'udp'], 'tcp').upper()
    dst_port = port('Porta destino')
    action = choice('Ação', ['accept', 'deny'], 'accept')
    nat = choice('SNAT da política (revisar central NAT)', ['enable', 'disable'], 'disable') if action == 'accept' else 'disable'
    logtraffic = choice('Logging', ['all', 'utm', 'disable'], 'all')
    print('\n[3/3] Objetos (nomes devem ser únicos ou previamente validados)')
    src_object = name('Nome do objeto de origem', 'SRC_' + change_id)
    dst_object = name('Nome do objeto de destino', 'DST_' + change_id)
    service_name = name('Nome do serviço customizado', f'SVC_{protocol}_{dst_port}_{change_id}')
    if len({src_object, dst_object}) != 2:
        raise ValueError('Objetos de origem e destino precisam ter nomes diferentes.')
    return dict(model=model, version=version, change_id=change_id, policy_name=policy_name,
                description=description, src=str(src), dst=str(dst), srcintf=srcintf,
                dstintf=dstintf, protocol=protocol, dst_port=dst_port, action=action,
                nat=nat, logtraffic=logtraffic, src_object=src_object,
                dst_object=dst_object, service_name=service_name)


def warning():
    print('\n' + '!' * 65)
    print(' WARNING - VERIFICAÇÃO OBRIGATÓRIA')
    print(' SALVAR BASELINE E BACKUP antes da MUDANÇA')
    print(' Verifique VDOM, política existente, ordem, NAT, roteamento,')
    print(' interfaces, objetos, segurança, GMUD e plano de rollback.')
    print('!' * 65)


def main():
    try:
        while True:
            rule = collect()
            config = build(rule)
            print('\n--- PRÉVIA DA CONFIGURAÇÃO ---\n')
            print(config)
            if choice('Salvar arquivos .cli e .json?', ['s', 'n'], 's') == 's':
                OUT.mkdir(parents=True, exist_ok=True)
                stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
                prefix = f'{rule["change_id"]}_{stamp}'
                cli = OUT / (prefix + '.cli')
                js = OUT / (prefix + '.json')
                cli.write_text(config, encoding='utf-8')
                js.write_text(json.dumps(rule, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
                print(f'Arquivo CLI: {cli}')
                print(f'Arquivo JSON: {js}')
            warning()
            if choice('Criar outra regra?', ['s', 'n'], 'n') == 'n':
                break
    except (KeyboardInterrupt, EOFError):
        print('\nExecução cancelada. Nenhuma alteração foi aplicada ao firewall.')
        warning()
    except ValueError as e:
        print(f'Erro de validação: {e}')
        warning()


if __name__ == '__main__':
    main()
