# Script principal
print('Sentinel OSINT 2025')