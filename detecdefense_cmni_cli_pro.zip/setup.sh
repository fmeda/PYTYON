#!/bin/bash
echo "[INFO] Verificando Python3..."
python3 --version || { echo "[ERROR] Python3 não encontrado"; exit 1; }
echo "[INFO] Instalando dependências Python..."
pip3 install requests pyyaml || { echo "[ERROR] Falha ao instalar pacotes"; exit 1; }
echo "[INFO] Verificando Docker..."
docker --version || { echo "[ERROR] Docker não encontrado"; exit 1; }
echo "[SUCCESS] Ambiente preparado. Crie config.yaml a partir de config.example.yaml"
