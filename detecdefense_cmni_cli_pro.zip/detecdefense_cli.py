#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# CMNI 2025+ CLI Professional-Ready

import os, sys, argparse, signal, yaml, re, requests, subprocess, time
from datetime import datetime

# Ctrl+C
def handle_sigint(signum, frame):
    print("\n[WARNING] Interrompido pelo usuário. Saindo...")
    sys.exit(130)
signal.signal(signal.SIGINT, handle_sigint)

# Config
CONFIG_PATH = os.environ.get("DETECDEFENSE_CONFIG", "config.yaml")
if not os.path.exists(CONFIG_PATH):
    print(f"[ERROR] Configuração não encontrada: {CONFIG_PATH}")
    sys.exit(1)

with open(CONFIG_PATH) as f:
    cfg = yaml.safe_load(f)

LOGDIR = cfg.get("log_dir", "logs")
os.makedirs(LOGDIR, exist_ok=True)

# Logging
def log(msg, level="INFO"):
    timestamp = datetime.utcnow().isoformat()
    with open(os.path.join(LOGDIR, "cli.log"), "a") as f:
        f.write(f"[{timestamp}] [{level}] {msg}\n")
    print(f"[{level}] {msg}")

# Sanitização
def sanitize_target(target):
    target = target.strip()
    if re.match(r"^(?:\d{1,3}\.){3}\d{1,3}$", target) or re.match(r"^[a-zA-Z0-9.-]+$", target):
        return target
    else:
        raise ValueError("IP ou domínio inválido")

# Retry simples
def retry_request(func, retries=3, backoff=2, *args, **kwargs):
    for i in range(retries):
        try:
            return func(*args, **kwargs)
        except requests.RequestException as e:
            log(f"[WARN] Tentativa {i+1} falhou: {e}", "WARN")
            time.sleep(backoff ** i)
    raise Exception(f"Todas tentativas falharam para {args} {kwargs}")

# Funções principais (simuladas)
def auto_blocker(target):
    target = sanitize_target(target)
    for fw in cfg.get("firewalls", []):
        log(f"[INFO] Bloqueando {target} no firewall {fw['name']}")

def suricata_rule_gen(feed_path, output_path):
    log(f"[INFO] Convertendo feed {feed_path} → {output_path}")

def dns_sinkhole(domains_path):
    log(f"[INFO] Injetando domínios de {domains_path}")

def honeypot_manager(action):
    log(f"[INFO] Executando honeypot ação '{action}'")

def siem_alert_router():
    log(f"[INFO] Roteando alertas SIEM")

# Menu CLI
def menu():
    while True:
        print("[1] Bloquear IP/domínio
[2] Converter feed → Suricata
[3] Injetar domínios DNS
[4] Gerenciar Honeypot
[5] Roteador SIEM
[0] Sair")
        choice=input("Selecione: ").strip()
        try:
            if choice=="1": auto_blocker(input("IP/domínio: "))
            elif choice=="2": suricata_rule_gen(input("Feed IOC: "), input("Arquivo saída: "))
            elif choice=="3": dns_sinkhole(input("Arquivo domínios: "))
            elif choice=="4": honeypot_manager(input("Ação [up|down|collect]: "))
            elif choice=="5": siem_alert_router()
            elif choice=="0": log("Encerrando CLI.","INFO"); sys.exit(0)
            else: log("Opção inválida.","WARN")
        except Exception as e:
            log(f"[ERROR] Erro inesperado: {e}","ERROR")

def main():
    parser=argparse.ArgumentParser(description="CMNI 2025+ CLI Professional-Ready")
    parser.add_argument("--help-menu", action="store_true", help="Mostra menu interativo")
    parser.add_argument("--version", action="version", version="CMNI CLI v5.0")
    args=parser.parse_args()
    if args.help_menu: menu()
    else: parser.print_help()

if __name__=="__main__": main()
