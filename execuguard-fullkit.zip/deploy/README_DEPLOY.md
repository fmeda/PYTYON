Deployment quicknotes:
- Dockerfile + compose for container runs and local testing
- k8s/cronjob-execuguard.yaml example for weekly CronJob
- Use imagePullSecrets for private registries
- Use Kubernetes Secret or external SecretsOperator for secret injection
