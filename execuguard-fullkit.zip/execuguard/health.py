# Minimal Flask app exposing /healthz and /metrics for Prometheus.
from __future__ import annotations
from flask import Flask, Response
from prometheus_client import generate_latest, CollectorRegistry, Gauge, CONTENT_TYPE_LATEST
import time

app = Flask('execuguard_health')
registry = CollectorRegistry()
last_run = Gauge('execuguard_last_run_timestamp', 'Last run timestamp (epoch seconds)', registry=registry)
reports_generated = Gauge('execuguard_reports_generated_total', 'Reports generated total', registry=registry)

# Set initial values (in real app update these during run)
last_run.set_to_current_time()
reports_generated.set(0)

@app.route('/healthz')
def healthz() -> str:
    return 'ok', 200

@app.route('/metrics')
def metrics() -> Response:
    data = generate_latest(registry)
    return Response(data, mimetype=CONTENT_TYPE_LATEST)

# Gunicorn entrypoint: app_worker must be callable by gunicorn
def app_worker():
    return app

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
