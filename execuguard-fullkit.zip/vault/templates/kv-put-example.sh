#!/usr/bin/env bash
# Example: write secrets to Vault KV v2
VAULT_ADDR=${VAULT_ADDR:-https://vault.example.com}
TOKEN=${VAULT_TOKEN}
vault kv put secret/execuguard zbx_password='REPLACE' wazuh_password='REPLACE' smtp_password='REPLACE'
