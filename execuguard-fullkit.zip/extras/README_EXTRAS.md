Extras provided in this kit:
- k8s manifests
- Vault policy and helper script
- GitHub Actions workflow
- Dockerfile and docker-compose
- Health & metrics (Flask + Prometheus)
