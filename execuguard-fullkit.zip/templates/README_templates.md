Templates directory contains the onepager HTML Jinja2 template used by ReportGenerator.
