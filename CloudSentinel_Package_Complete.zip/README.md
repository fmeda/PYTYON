# CloudSentinel

## Instalação
```bash
python3 CloudSentinel.py
```

## Pré-requisitos
- Python 3.10+
- Variáveis de ambiente:
  - VT_API_KEY
  - SLACK_WEBHOOK_URL (opcional)
  - EMAIL_ALERT (opcional)

## Funcionalidades
- Monitoramento de logs
- Detecção de credenciais comprometidas
- Hardening CIS
- Relatórios HTML/PDF
- CLI interativa
