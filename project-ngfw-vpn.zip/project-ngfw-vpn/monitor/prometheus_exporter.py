#!/usr/bin/env python3
"""
Prometheus Exporter para métricas do wg-mgmt
"""

import logging, sys, subprocess, importlib, time, random

def ensure_package(pkg: str):
    try:
        return importlib.import_module(pkg)
    except ImportError:
        print(f"[INFO] Pacote {pkg} não encontrado. Instalando...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
        return importlib.import_module(pkg)

# garante que prometheus_client esteja instalado
prometheus_client = ensure_package("prometheus_client")
from prometheus_client import start_http_server, Gauge

logging.basicConfig(level=logging.INFO)
LOG = logging.getLogger("prometheus-exporter")

# Métricas
leader_g = Gauge('wg_mgmt_leader', '1 se este nó é líder, 0 caso contrário')
peers_g = Gauge('wg_mgmt_peers_total', 'Total de peers registrados')

def collect_metrics():
    try:
        while True:
            # ⚠️ Placeholder: substitua por métricas reais
            leader_g.set(random.choice([0, 1]))
            peers_g.set(random.randint(0, 50))
            LOG.info("Atualizando métricas: leader=%s peers=%s",
                     leader_g._value.get(), peers_g._value.get())
            time.sleep(10)
    except KeyboardInterrupt:
        LOG.info("Exporter interrompido pelo usuário (CTRL+C). Saindo com segurança...")

if __name__ == "__main__":
    LOG.info("Iniciando Prometheus exporter na porta 9000")
    start_http_server(9000)
    collect_metrics()
