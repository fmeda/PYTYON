import subprocess, base64, tempfile, logging, os
LOG = logging.getLogger("attestation")

ATTTEST_VERIFY_CMD = os.environ.get("ATTEST_VERIFY_CMD", "/app/verify_attestation.sh")
ALLOWED_PCRS = os.environ.get("ALLOWED_PCRS", "0,7")

def verify_attestation(attestation_b64: str, device_id: str) -> bool:
    try:
        att_bytes = base64.b64decode(attestation_b64)
    except Exception:
        LOG.error("invalid base64 attestation")
        return False
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(att_bytes); f.flush()
        cmd = [ATTTEST_VERIFY_CMD, f.name, device_id, ALLOWED_PCRS]
        res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        LOG.info("attestation result code=%s out=%s err=%s",
                 res.returncode, res.stdout.decode(), res.stderr.decode())
        return res.returncode == 0
