import os, tempfile, subprocess, datetime, re, logging
LOG = logging.getLogger("wg-utils")

WG_CONF = os.environ.get("WG_CONF", "/etc/wireguard/wg0.conf")
WG_IFACE = os.environ.get("WG_IFACE", "wg0")

def add_peer_to_conf(pubkey, allowed_ip, comment):
    peer_block = f"""

# added-by-mgmt {comment} {datetime.datetime.utcnow().isoformat()}
[Peer]
PublicKey = {pubkey}
AllowedIPs = {allowed_ip}
"""
    with tempfile.NamedTemporaryFile(prefix="wgconf_", delete=False) as tf:
        with open(WG_CONF, "r") as orig:
            tf.write(orig.read().encode())
        tf.write(peer_block.encode())
        tmp_path = tf.name
    os.chmod(tmp_path, 0o600)
    res = subprocess.run(["wg", "syncconf", WG_IFACE, tmp_path],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode != 0:
        os.remove(tmp_path)
        raise RuntimeError("wg syncconf failed: " + res.stderr.decode())
    os.rename(tmp_path, f"/var/lib/wg-mgmt/wg0.{datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S')}.conf")

def remove_peer_from_conf(pubkey):
    with open(WG_CONF, "r") as f: data = f.read()
    pattern = re.compile(r"\n# added-by-mgmt .*?\n\[Peer\]\nPublicKey = %s\n(?:.*?)(?=\n\[Peer\]|\Z)" % pubkey, re.S)
    new = re.sub(pattern, "\n", data)
    with tempfile.NamedTemporaryFile(prefix="wgconf_", delete=False) as tf:
        tf.write(new.encode()); tmp_path = tf.name
    os.chmod(tmp_path, 0o600)
    res = subprocess.run(["wg", "syncconf", WG_IFACE, tmp_path],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if res.returncode != 0:
        os.remove(tmp_path)
        raise RuntimeError("wg syncconf failed")
    os.rename(tmp_path, f"/var/lib/wg-mgmt/wg0.removed.{datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S')}.conf")
