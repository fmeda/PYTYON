#!/usr/bin/env bash
# usage: verify_attestation.sh <att_blob_file> <device_id> <allowed_pcrs>
set -euo pipefail
ATT="$1"; DEVICE="$2"; PCRS="$3"

# Exemplo stub: aceita se blob contiver string TPM-QUOTE
if grep -q "TPM-QUOTE" "$ATT"; then
  echo "attestation-ok for $DEVICE"
  exit 0
else
  echo "attestation-failed" >&2
  exit 2
fi
