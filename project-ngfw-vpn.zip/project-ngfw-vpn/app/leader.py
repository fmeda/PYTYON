import os, time, uuid, threading
import etcd3

ETCD_ENDPOINTS = os.environ.get("ETCD_ENDPOINTS", "http://etcd:2379").split(",")
LOCK_KEY       = os.environ.get("ETCD_LOCK_KEY", "/wg-mgmt/lock/wg0")
LEASE_TTL      = int(os.environ.get("ETCD_LEASE_TTL", "15"))
RENEW_MARGIN   = int(os.environ.get("ETCD_RENEW_MARGIN", "5"))

class EtcdLeader:
    def __init__(self):
        host, port = self._pick()
        self.cli = etcd3.client(host=host, port=int(port))
        self.lease = None
        self.holder_id = f"{uuid.uuid4()}"
        self._stop = threading.Event()

    def _pick(self):
        for ep in ETCD_ENDPOINTS:
            ep = ep.strip().replace("http://","").replace("https://","")
            h,p = (ep.split(":",1) if ":" in ep else (ep,"2379"))
            return h,p
        return "localhost","2379"

    def try_acquire(self):
        self.lease = self.cli.lease(LEASE_TTL)
        ok = self.cli.transaction(
            compare=[self.cli.transactions.version(LOCK_KEY) == 0],
            success=[self.cli.transactions.put(LOCK_KEY, self.holder_id, lease=self.lease)],
            failure=[]
        )
        if ok:
            threading.Thread(target=self._keepalive, daemon=True).start()
        return ok

    def _keepalive(self):
        while not self._stop.is_set():
            time.sleep(max(1, LEASE_TTL - RENEW_MARGIN))
            try: self.lease.refresh()
            except Exception: break

    def release(self):
        try: self.cli.delete(LOCK_KEY)
        except: pass
        if self.lease:
            try: self.lease.revoke()
            except: pass
        self._stop.set()

    def is_leader(self):
        try:
            val,_ = self.cli.get(LOCK_KEY)
            return (val or b"").decode() == self.holder_id
        except: return False

    def leader_context(self):
        class _Ctx:
            def __init__(self, outer): self.outer=outer
            def __enter__(self):
                if not self.outer.try_acquire():
                    raise RuntimeError("not leader")
                return True
            def __exit__(self, a,b,c): self.outer.release()
        return _Ctx(self)
