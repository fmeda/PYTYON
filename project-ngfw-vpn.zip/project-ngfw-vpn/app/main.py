import base64, json, logging, os, sqlite3, subprocess, tempfile, hashlib, re, datetime
from fastapi import FastAPI, Request, HTTPException
from pydantic import BaseModel
from leader import EtcdLeader
from attestation import verify_attestation
from wg_utils import add_peer_to_conf, remove_peer_from_conf

LOG = logging.getLogger("wg-mgmt")
logging.basicConfig(level=logging.INFO)

DB_PATH = os.environ.get("WG_MGMT_DB", "/data/wg-mgmt.db")
LEAD_LOCK = EtcdLeader()

app = FastAPI(title="WG Management API")

# ---------------- Models ----------------
class RegisterRequest(BaseModel):
    device_id: str
    pubkey: str
    attestation: str
    meta: dict = {}

class RevokeRequest(BaseModel):
    device_id: str
    pubkey: str

# ---------------- DB helpers ----------------
def init_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS peers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id TEXT,
        pubkey TEXT UNIQUE,
        registered_at TEXT,
        attestation_ok INTEGER,
        meta TEXT
    )
    """)
    conn.commit()
    return conn

DB = init_db()

def record_peer(device_id, pubkey, att_ok, meta):
    cur = DB.cursor()
    cur.execute("INSERT OR REPLACE INTO peers(device_id,pubkey,registered_at,attestation_ok,meta) VALUES(?,?,?,?,?)",
                (device_id, pubkey, datetime.datetime.utcnow().isoformat(), int(att_ok), json.dumps(meta)))
    DB.commit()

def remove_peer(pubkey):
    cur = DB.cursor()
    cur.execute("DELETE FROM peers WHERE pubkey=?", (pubkey,))
    DB.commit()

# ---------------- Endpoints ----------------
@app.post("/api/wg-register")
async def register(req: RegisterRequest, request: Request):
    LOG.info("register attempt device=%s", req.device_id)
    att_ok = verify_attestation(req.attestation, req.device_id)
    if not att_ok:
        raise HTTPException(status_code=403, detail="attestation failed")

    h = hashlib.sha256(req.device_id.encode()).digest()
    last = h[0] % 250 + 2
    allowed_ip = f"10.50.0.{last}/32"

    try:
        with LEAD_LOCK.leader_context():
            add_peer_to_conf(req.pubkey, allowed_ip, req.device_id)
            record_peer(req.device_id, req.pubkey, True, req.meta or {})
    except RuntimeError:
        raise HTTPException(status_code=409, detail="not a leader; retry another node")
    except Exception:
        LOG.exception("failed to add peer")
        raise HTTPException(status_code=500, detail="failed to add peer to wg")

    return {"status":"ok","allowed_ip":allowed_ip}

@app.post("/api/wg-revoke")
async def revoke(r: RevokeRequest, request: Request):
    try:
        with LEAD_LOCK.leader_context():
            remove_peer_from_conf(r.pubkey)
            remove_peer(r.pubkey)
    except RuntimeError:
        raise HTTPException(status_code=409, detail="not a leader; retry another node")
    except Exception:
        LOG.exception("failed removing peer")
        raise HTTPException(status_code=500, detail="failed to remove peer")
    return {"status":"revoked"}

@app.get("/healthz")
async def health():
    return {"ok": True, "leader": LEAD_LOCK.is_leader()}
