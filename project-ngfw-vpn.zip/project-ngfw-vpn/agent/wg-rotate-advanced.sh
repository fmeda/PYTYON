#!/bin/bash
# Rotação de chaves WireGuard com attestation TPM e fallback HA
set -euo pipefail

MGMT_ENDPOINTS=("https://mgmt1.local:8000" "https://mgmt2.local:8000")
WG_IFACE="wg0"
DEVICE_ID="$(hostname)-$(uuidgen)"
TMP_DIR="/tmp/wg-rotate"
mkdir -p "$TMP_DIR"

# gera par efêmero
wg genkey | tee "$TMP_DIR/private.key" | wg pubkey > "$TMP_DIR/public.key"
PUB=$(cat "$TMP_DIR/public.key")

# gera quote TPM simulado
echo "TPM-QUOTE $(date)" | base64 > "$TMP_DIR/attestation.b64"
ATT=$(cat "$TMP_DIR/attestation.b64")

# registra no mgmt
for ep in "${MGMT_ENDPOINTS[@]}"; do
  echo "Tentando $ep ..."
  RESP=$(curl -sk -X POST "$ep/api/wg-register" \
    -H "Content-Type: application/json" \
    -d "{\"device_id\":\"$DEVICE_ID\",\"pubkey\":\"$PUB\",\"attestation\":\"$ATT\"}")
  if grep -q "allowed_ip" <<<"$RESP"; then
    echo "Sucesso: $RESP"
    ALLOWED_IP=$(echo "$RESP" | jq -r .allowed_ip)
    wg set "$WG_IFACE" private-key "$TMP_DIR/private.key" peer "$PUB" allowed-ips "$ALLOWED_IP"
    exit 0
  fi
done

echo "Falha ao registrar peer"
exit 1
