#!/bin/bash
# Coleta TPM quote (exemplo simplificado)
set -euo pipefail
OUT=$1
echo "TPM-QUOTE $(date)" > "$OUT"
