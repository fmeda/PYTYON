# Políticas de Segurança e Ciclo de Vida Criptográfico

Este documento descreve as práticas de segurança aplicadas no **Projeto 2: NGFW + Full Disk Encryption + VPN Always-On**.

---

## 🔑 Ciclo de Vida Criptográfico

### Chaves de Sessão
- **WireGuard**  
  - Geração efêmera a cada rotação do script `wg-rotate-advanced.sh`.  
  - Rotação periódica (6h) com registro via API de gestão.  
  - Persistência mínima para reduzir impacto em caso de comprometimento.  

- **IPSec/IKEv2**  
  - Perfect Forward Secrecy (PFS) habilitado.  
  - Algoritmos fortes: AES-256 + SHA2-256 + modp4096.  

- **TLS (API de Gestão)**  
  - Certificados curtos (≤90 dias).  
  - mTLS obrigatório entre agentes e servidores de gestão.  

### Criptografia de Disco
- **LUKS2 + TPM**  
  - Chave mestra armazenada de forma selada no TPM.  
  - `passphrase` de fallback em caso de falha no TPM.  
  - Re-derivação da chave em cada boot (anti-replay).  

### Attestation
- Validação de integridade com TPM Quote.  
- Uso de nonces para evitar ataques de replay.  
- Apenas peers com attestation válido são aceitos pelo servidor de gestão.  

---

## 🔒 Hardening de Endpoints
- **Split tunneling desativado** em todas as VPNs.  
- **Sysmon** configurado para:  
  - Bloquear ou alertar drivers não assinados.  
  - Detectar ferramentas ofensivas (`mimikatz`, `psexec`).  
  - Monitorar tráfego DNS suspeito ou tunelamento.  
- **FDE (Full Disk Encryption)** obrigatório em dispositivos.  

---

## 🔥 Políticas NGFW
- Bloqueio de tráfego fora da VPN.  
- Inspeção de tráfego (DPI) e IPS habilitados.  
- Logging centralizado no **FortiAnalyzer**.  

---

## 📊 Monitoramento e Alertas
- **Indicadores principais**:  
  - Status da VPN Always-On.  
  - Troca de chaves IKE/WireGuard.  
  - Tentativas de acesso não autorizado.  

- **Logs coletados em**:  
  - **FortiAnalyzer** – incidentes e eventos de rede.  
  - **Prometheus** – métricas operacionais.  

---

## 🛡 Resposta a Incidentes
1. Revogação imediata de chave comprometida via `/api/wg-revoke`.  
2. Bloqueio de IP no FortiGate.  
3. Geração de relatório no FortiAnalyzer.  
4. Coleta de evidências (Sysmon + logs de disco criptografado).  
5. Quarentena automática via integração FortiGate API.  

---

## ♻️ Ciclo de Revisão
- **Firewall**: revisão trimestral das regras.  
- **Chaves da API**: rotação mensal.  
- **Auditoria de endpoints**: contínua (atestado + Sysmon).  
- **Políticas de criptografia**: revisão anual ou sempre que surgirem vulnerabilidades relevantes.  
