# Projeto 2 – NGFW + Full Disk Encryption + VPN Always-On

## 🎯 Objetivo
Garantir proteção de sessão mesmo em endpoints remotos, com encapsulamento e criptografia contínua.  
O projeto integra **WireGuard Always-On VPN**, **NGFW FortiGate**, **criptografia de disco (LUKS2+TPM)** e monitoramento contínuo.

---

## 🏗 Arquitetura
- **NGFW FortiGate** – firewall de próxima geração com **DPI** e **IPS**.
- **VPN** – WireGuard com rotação automática de chaves efêmeras e fallback IPSec/IKEv2 com PFS.
- **Criptografia de Disco** – LUKS2 + TPM, chave atrelada ao hardware.
- **Alta Disponibilidade** – múltiplos nós `wg-mgmt` coordenados via **etcd leader election**.
- **Monitoramento** – FortiAnalyzer, Sysmon e Prometheus.

---

## 📂 Estrutura do Repositório
