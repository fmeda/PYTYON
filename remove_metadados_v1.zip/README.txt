Remove Metadados - Ferramenta Python CLI
========================================

Este script remove metadados de arquivos do tipo:
- Imagens (JPG, PNG, BMP, etc.)
- PDF
- Documentos Microsoft Office (DOCX, XLSX, PPTX)

Instruções de uso:
------------------
1. Certifique-se de ter o Python 3 instalado.
2. Execute no terminal:

   python remove_metadados.py <caminho_do_arquivo>

   Exemplo:
   python remove_metadados.py exemplo.pdf

O script verifica automaticamente se os módulos necessários estão instalados e realiza a instalação caso não estejam.
