import os
import sys
import subprocess
import importlib.util

DEPENDENCIAS = {
    "PIL": "pillow",
    "PyPDF2": "PyPDF2",
    "docx": "python-docx",
    "openpyxl": "openpyxl",
    "pptx": "python-pptx"
}

def checar_e_instalar_dependencias():
    for modulo, pacote in DEPENDENCIAS.items():
        if not importlib.util.find_spec(modulo):
            print(f"[!] Modulo '{modulo}' nao encontrado. Instalando pacote '{pacote}'...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", pacote])
        else:
            print(f"[✓] Modulo '{modulo}' ja esta instalado.")

checar_e_instalar_dependencias()

from PIL import Image
from PyPDF2 import PdfReader, PdfWriter
from docx import Document
from openpyxl import load_workbook
from pptx import Presentation

def remover_metadados_imagem(caminho):
    img = Image.open(caminho)
    dados_puros = Image.new(img.mode, img.size)
    dados_puros.putdata(list(img.getdata()))
    novo_caminho = gerar_novo_nome(caminho)
    dados_puros.save(novo_caminho)
    print(f"[✓] Metadados da imagem removidos: {novo_caminho}")

def remover_metadados_pdf(caminho):
    reader = PdfReader(caminho)
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    writer.add_metadata({})
    novo_caminho = gerar_novo_nome(caminho)
    with open(novo_caminho, "wb") as f:
        writer.write(f)
    print(f"[✓] Metadados do PDF removidos: {novo_caminho}")

def remover_metadados_docx(caminho):
    doc = Document(caminho)
    novo_caminho = gerar_novo_nome(caminho)
    doc.save(novo_caminho)
    print(f"[✓] Metadados do DOCX removidos: {novo_caminho}")

def remover_metadados_xlsx(caminho):
    wb = load_workbook(caminho)
    wb.properties = None
    novo_caminho = gerar_novo_nome(caminho)
    wb.save(novo_caminho)
    print(f"[✓] Metadados do XLSX removidos: {novo_caminho}")

def remover_metadados_pptx(caminho):
    prs = Presentation(caminho)
    novo_caminho = gerar_novo_nome(caminho)
    prs.save(novo_caminho)
    print(f"[✓] Metadados do PPTX removidos: {novo_caminho}")

def gerar_novo_nome(caminho):
    nome, ext = os.path.splitext(caminho)
    return f"{nome}_limpo{ext}"

def identificar_tipo_e_remover(caminho):
    ext = caminho.lower().split('.')[-1]
    if ext in ['jpg', 'jpeg', 'png', 'bmp', 'gif', 'tiff']:
        remover_metadados_imagem(caminho)
    elif ext == 'pdf':
        remover_metadados_pdf(caminho)
    elif ext == 'docx':
        remover_metadados_docx(caminho)
    elif ext == 'xlsx':
        remover_metadados_xlsx(caminho)
    elif ext == 'pptx':
        remover_metadados_pptx(caminho)
    else:
        print(f"[!] Tipo de arquivo nao suportado: {caminho}")

def main():
    if len(sys.argv) < 2:
        print("Uso: python remove_metadados.py <arquivo1> [arquivo2] [arquivo3] ...")
        return

    arquivos = sys.argv[1:]
    for caminho in arquivos:
        if not os.path.isfile(caminho):
            print(f"[!] Arquivo nao encontrado: {caminho}")
            continue
        print(f"Processando arquivo: {caminho}")
        identificar_tipo_e_remover(caminho)

if __name__ == "__main__":
    main()
