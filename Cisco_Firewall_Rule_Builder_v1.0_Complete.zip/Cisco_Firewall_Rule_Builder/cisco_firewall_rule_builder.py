#!/usr/bin/env python3
"""Cisco Firewall Rule Builder - gerador offline, sem deploy automático."""
import ipaddress
import json
import re
from datetime import datetime
from pathlib import Path

OUT = Path.cwd() / 'firewall_rules'


def ask(label, default='', required=True):
    while True:
        suffix = f' [{default}]' if default else ''
        value = input(f'{label}{suffix}: ').strip() or default
        if value or not required:
            return value
        print('  ! Campo obrigatório.')


def choose(label, choices):
    print(f'\n{label}')
    for n, option in enumerate(choices, 1):
        print(f'  {n}. {option}')
    while True:
        v = input('Selecione o número: ').strip()
        if v.isdigit() and 1 <= int(v) <= len(choices):
            return choices[int(v)-1]
        print('  ! Opção inválida.')


def network(label):
    while True:
        raw = ask(label)
        try:
            return str(ipaddress.IPv4Network(raw, strict=False))
        except ValueError:
            print('  ! Informe IPv4 ou CIDR válido (ex.: 10.0.0.10 ou 10.0.0.0/24).')


def token(label, default, pattern=r'[A-Za-z][A-Za-z0-9_.-]{0,63}'):
    while True:
        v = ask(label, default)
        if re.fullmatch(pattern, v):
            return v
        print('  ! Use apenas letras, números, ponto, hífen ou underscore; comece com letra.')


def port(label, default='443'):
    while True:
        v = ask(label, default)
        if v.isdigit() and 1 <= int(v) <= 65535:
            return int(v)
        print('  ! Porta TCP/UDP deve estar entre 1 e 65535.')


def yesno(label, default=True):
    v = ask(label + ' (s/n)', 's' if default else 'n').lower()
    return v in ('s', 'sim', 'y', 'yes')


def wildcard(net):
    n = ipaddress.IPv4Network(net)
    return str(n.network_address), str(n.hostmask)


def asa_network(net):
    n = ipaddress.IPv4Network(net)
    if n.prefixlen == 32:
        return f'host {n.network_address}'
    return f'{n.network_address} {n.netmask}'


def ios_network(net):
    n = ipaddress.IPv4Network(net)
    if n.prefixlen == 32:
        return f'host {n.network_address}'
    ip, mask = wildcard(net)
    return f'{ip} {mask}'


def generate(d):
    platform = d['platform']
    proto = d['protocol'].lower()
    act = 'permit' if d['action'] == 'ALLOW' else 'deny'
    destport = f' eq {d["port"]}' if proto in ('tcp', 'udp') else ''
    banner = [f'! Cisco Firewall Rule Builder | {d["created_at"]}',
              f'! Change ID: {d["change_id"]}', f'! Model: {d["model"]} | Version: {d["version"]}',
              '! REVIEW REQUIRED: existing policy, routing, NAT, interfaces, logging and rule order.',
              '! NO AUTOMATIC DEPLOYMENT', '!']
    if platform == 'Cisco ASA':
        rule = f'access-list {d["acl"]} extended {act} {proto} {asa_network(d["source"])} {asa_network(d["destination"])}{destport}'
        if d['logging']:
            rule += ' log'
        lines = banner + ['conf t', rule,
                          f'! REVIEW ONLY: access-group {d["acl"]} in interface {d["interface"]}',
                          '! Existing access-group association must be verified before changes.', 'end']
        return '\n'.join(lines) + '\n', 'cli'
    if platform == 'Cisco IOS / IOS XE ACL':
        rule = f' {act} {proto} {ios_network(d["source"])} {ios_network(d["destination"])}{destport}'
        if d['logging']:
            rule += ' log'
        lines = banner + ['conf t', f'ip access-list extended {d["acl"]}',
                          f' remark Change {d["change_id"]}', rule, 'exit',
                          f'! REVIEW ONLY: interface {d["interface"]}',
                          f'! REVIEW ONLY: ip access-group {d["acl"]} {d["direction"]}',
                          '! ACL is not attached automatically; check existing policies and implicit deny.', 'end']
        return '\n'.join(lines) + '\n', 'cli'
    if platform == 'Cisco IOS XE ZBFW':
        if d['action'] == 'DENY':
            # In ZBFW deny is explicit drop class, with no inspect.
            behavior = 'drop log' if d['logging'] else 'drop'
        else:
            behavior = 'inspect'
        acl = f' permit {proto} {ios_network(d["source"])} {ios_network(d["destination"])}{destport}'
        lines = banner + ['conf t', f'ip access-list extended {d["acl"]}', acl, 'exit',
                          f'zone security {d["source_zone"]}', f'zone security {d["destination_zone"]}',
                          f'class-map type inspect match-all {d["class_map"]}',
                          f' match access-group name {d["acl"]}', 'exit',
                          f'policy-map type inspect {d["policy_map"]}',
                          f' class type inspect {d["class_map"]}', f'  {behavior}', ' exit',
                          ' class class-default', '  drop', ' exit', 'exit',
                          f'zone-pair security {d["zone_pair"]} source {d["source_zone"]} destination {d["destination_zone"]}',
                          f' service-policy type inspect {d["policy_map"]}', 'exit',
                          '! REVIEW: interface-to-zone assignment is intentionally not generated.',
                          '! REVIEW: zone-pair uniqueness, existing policy, intra-zone flows and default drops.',
                          '! REVIEW: deny-class ordering and logging support on this IOS XE release.', 'end']
        return '\n'.join(lines) + '\n', 'cli'
    lines = banner + ['! FTD / FMC: POLICY SPECIFICATION ONLY - NOT DEVICE CLI',
                      f'! Action: {d["action"]}', f'! Source zone: {d["source_zone"]}',
                      f'! Destination zone: {d["destination_zone"]}',
                      f'! Source: {d["source"]}', f'! Destination: {d["destination"]}',
                      f'! Protocol: {proto.upper()}', f'! Destination port: {d["port"] if d["port"] else "N/A"}',
                      f'! Logging: {"Enabled" if d["logging"] else "Disabled"}',
                      '! Configure in Access Control Policy via FMC/FDM, verify IPS, NAT and deploy.']
    return '\n'.join(lines) + '\n', 'txt'


def main():
    print('\n' + '='*64)
    print('  CISCO FIREWALL RULE BUILDER  |  Offline / Review First')
    print('='*64)
    while True:
        d = {}
        d['platform'] = choose('Plataforma', ['Cisco ASA', 'Cisco IOS / IOS XE ACL', 'Cisco IOS XE ZBFW', 'Cisco FTD / FMC'])
        d['model'] = ask('Modelo/PID (ex.: FPR-3110, C8300)', 'NÃO INFORMADO')
        d['version'] = ask('Versão do sistema operacional', 'NÃO INFORMADA')
        d['change_id'] = token('ID da GMUD', 'CHG-2026-001')
        d['source'] = network('Rede/IP de origem (IPv4/CIDR)')
        d['destination'] = network('Rede/IP de destino (IPv4/CIDR)')
        d['protocol'] = choose('Protocolo', ['TCP', 'UDP', 'ICMP', 'IP'])
        d['port'] = port('Porta de destino') if d['protocol'] in ('TCP', 'UDP') else None
        d['action'] = choose('Ação', ['ALLOW', 'DENY'])
        d['logging'] = yesno('Habilitar logging?', True)
        if d['platform'] in ('Cisco ASA', 'Cisco IOS / IOS XE ACL', 'Cisco IOS XE ZBFW'):
            d['acl'] = token('Nome da ACL', 'ACL_APP_WEB')
        if d['platform'] == 'Cisco ASA':
            d['interface'] = token('Interface ASA de entrada', 'inside')
        elif d['platform'] == 'Cisco IOS / IOS XE ACL':
            d['interface'] = ask('Interface alvo (ex.: GigabitEthernet0/0/0)')
            d['direction'] = choose('Direção da ACL', ['in', 'out'])
        else:
            d['source_zone'] = token('Zona de origem', 'APP')
            d['destination_zone'] = token('Zona de destino', 'DC_SERVERS')
            if d['source_zone'] == d['destination_zone'] and d['platform'] == 'Cisco IOS XE ZBFW':
                print('  ! ZBFW entre a mesma zona requer análise especial; não gere zone-pair intra-zona.')
                continue
            if d['platform'] == 'Cisco IOS XE ZBFW':
                d['class_map'] = token('Nome da class-map', 'CM_APP_WEB')
                d['policy_map'] = token('Nome da policy-map', 'PM_APP_DC')
                d['zone_pair'] = token('Nome do zone-pair', 'ZP_APP_DC')
        d['created_at'] = datetime.now().astimezone().isoformat(timespec='seconds')
        config, ext = generate(d)
        print('\n' + '-'*64 + '\nRESUMO DA REGRA\n' + '-'*64)
        for key, value in d.items():
            print(f'  {key:20}: {value}')
        print('\n' + '-'*64 + '\nPRÉVIA DA CONFIGURAÇÃO\n' + '-'*64)
        print(config)
        if yesno('Salvar arquivos?', True):
            OUT.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            basename = f'{d["change_id"]}_{stamp}'
            config_path = OUT / f'{basename}.{ext}'
            json_path = OUT / f'{basename}.json'
            config_path.write_text(config, encoding='utf-8')
            json_path.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding='utf-8')
            print(f'\n  Configuração: {config_path}')
            print(f'  Dados JSON:   {json_path}')
        print('\n' + '!' * 72)
        print('WARNING - VERIFICAÇÃO OBRIGATÓRIA ANTES DA MUDANÇA')
        print('SALVAR BASELINE E BACKUP antes da MUDANÇA')
        print('Cheque o ambiente, as ACLs/políticas existentes, NAT, roteamento,')
        print('interfaces/zonas, impacto operacional e plano de rollback.')
        print('Revise a compatibilidade com o PID/versão Cisco antes de aplicar.')
        print('!' * 72)
        if not yesno('Criar outra regra?', False):
            print('Encerrado.')
            break


if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print('\nOperação cancelada.')
