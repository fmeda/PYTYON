# CISCO FIREWALL RULE BUILDER v1.0 — GUIA DE AJUDA

**Tipo:** Manual de operação da interface de linha de comando (CLI)  
**Idioma:** Português (Brasil)  
**Objetivo:** Orientar a criação, revisão e exportação de regras Cisco sem aplicá-las automaticamente.

## 1. O que o programa faz

O arquivo `cisco_firewall_rule_builder.py` apresenta um assistente interativo no terminal. Ele coleta informações de uma regra, mostra um resumo, gera uma prévia e permite salvar a configuração e seus metadados. **O programa não se conecta a equipamentos e não executa deploy.**

Plataformas disponíveis:

| Opção | Plataforma | Saída | Observação |
|---|---|---|---|
| 1 | Cisco ASA | `.cli` | Gera linha de ACL; associação à interface fica como comentário para revisão. |
| 2 | Cisco IOS / IOS XE ACL | `.cli` | Gera ACL estendida; associação à interface fica como comentário. |
| 3 | Cisco IOS XE ZBFW | `.cli` | Gera modelo de ACL, class-map, policy-map, zonas e zone-pair; exige revisão especial. |
| 4 | Cisco FTD / FMC | `.txt` | **Especificação de política**, não comandos para executar no FTD. Configurar via FMC/FDM. |

Todas as opções também podem gerar um arquivo `.json` com os campos informados.

## 2. Requisitos e instalação

- Python 3.8 ou superior recomendado (sem dependências externas).
- Terminal Windows (PowerShell ou Prompt), Linux ou macOS.
- Permissão de escrita no diretório de execução para salvar os arquivos.

Coloque o script em uma pasta de trabalho e execute:

```bash
python3 cisco_firewall_rule_builder.py
```

No Windows, se `python3` não estiver disponível:

```powershell
py cisco_firewall_rule_builder.py
```

Para confirmar a instalação:

```bash
python3 --version
```

## 3. Fluxo de uso — passo a passo

1. **Plataforma:** digite `1`, `2`, `3` ou `4` e pressione Enter.
2. **Modelo/PID:** informe, por exemplo, `FPR-3110` ou `C8300`. O script registra o valor, mas **não verifica a compatibilidade**.
3. **Versão:** informe a versão real do sistema, por exemplo `17.12.4` ou `7.6.x`.
4. **ID da GMUD:** identificador da mudança, por exemplo `CHG-2026-001`. Deve começar por letra e conter apenas letras, números, ponto, hífen e underscore.
5. **Origem e destino:** informe IPv4 ou rede CIDR, por exemplo `10.10.10.0/24` e `172.16.20.10`. Um IP isolado é tratado como `/32`.
6. **Protocolo:** escolha `TCP`, `UDP`, `ICMP` ou `IP`. Para TCP/UDP, informe uma **porta de destino** de `1` a `65535`.
7. **Ação:** selecione `ALLOW` ou `DENY`.
8. **Logging:** responda `s` para sim ou `n` para não.
9. **Campos adicionais:** variam conforme a plataforma (veja seção 4).
10. **Revisão:** confira o resumo e a prévia exibidos no terminal.
11. **Exportação:** responda `s` à pergunta `Salvar arquivos?` para gerar os arquivos na pasta `firewall_rules`.
12. **WARNING:** leia o alerta de segurança e decida se deseja criar outra regra.

**Dica:** quando aparecer um valor entre colchetes, como `[443]`, pressionar Enter utiliza esse valor padrão.

## 4. Campos específicos por plataforma

### Cisco ASA

- **Nome da ACL:** exemplo `ACL_APP_WEB`.
- **Interface ASA de entrada:** exemplo `inside`.
- O script **não aplica** automaticamente `access-group`; essa linha é apresentada como comentário.
- Antes de usar a ACL, confira NAT, ACL associada, ordem das entradas e sintaxe para a versão ASA.

### Cisco IOS / IOS XE ACL

- **Nome da ACL:** exemplo `ACL_APP_WEB`.
- **Interface alvo:** exemplo `GigabitEthernet0/0/0`.
- **Direção:** `in` ou `out`.
- O script gera a definição da ACL, mas **não associa** a ACL à interface.
- Verifique ACL existente, `deny` implícito, roteamento, gerenciamento e impacto sobre tráfego não contemplado.

### Cisco IOS XE Zone-Based Firewall (ZBFW)

- **Nome da ACL:** exemplo `ACL_APP_WEB`.
- **Zona de origem:** exemplo `APP`.
- **Zona de destino:** exemplo `DC_SERVERS`.
- **Class-map:** exemplo `CM_APP_WEB`.
- **Policy-map:** exemplo `PM_APP_DC`.
- **Zone-pair:** exemplo `ZP_APP_DC`.
- O programa impede a criação de zone-pair quando as duas zonas informadas são iguais.
- **Atenção:** o modelo gerado pode conflitar com objetos existentes e políticas aplicadas. Não associa interfaces às zonas. Revise as classes, a ordem, o comportamento `inspect`/`drop`, o logging e o efeito de `class-default drop`.

### Cisco FTD / FMC

- **Zona de origem e zona de destino:** exemplos `APP` e `DC_SERVERS`.
- A saída é um **arquivo de especificação `.txt`**, não uma CLI executável.
- Crie a regra na Access Control Policy do FMC/FDM, revise posição da regra, objetos, NAT, IPS, logging e efetue o deploy somente após aprovação.

## 5. Exemplo completo — IOS XE ACL

Entradas de exemplo:

```text
Plataforma: 2 (Cisco IOS / IOS XE ACL)
Modelo/PID: C8300
Versão: 17.12.4
ID da GMUD: CHG-2026-001
Rede/IP de origem: 10.10.10.0/24
Rede/IP de destino: 172.16.20.10
Protocolo: 1 (TCP)
Porta de destino: 443
Ação: 1 (ALLOW)
Habilitar logging?: s
Nome da ACL: ACL_APP_WEB
Interface alvo: GigabitEthernet0/0/0
Direção: 1 (in)
Salvar arquivos?: s
```

Trecho ilustrativo da saída:

```text
conf t
ip access-list extended ACL_APP_WEB
 remark Change CHG-2026-001
 permit tcp 10.10.10.0 0.0.0.255 host 172.16.20.10 eq 443 log
exit
! REVIEW ONLY: interface GigabitEthernet0/0/0
! REVIEW ONLY: ip access-group ACL_APP_WEB in
! ACL is not attached automatically; check existing policies and implicit deny.
end
```

**Não cole cegamente esse bloco em produção:** confirme se a ACL já existe e se a entrada deve ser inserida em uma sequência específica. Uma ACL aplicada sem permissões complementares pode interromper serviços.

## 6. Arquivos de saída

Quando o usuário escolhe salvar, o programa cria uma pasta chamada `firewall_rules` no **diretório atual de execução**. Os arquivos seguem um padrão como:

```text
firewall_rules/
  CHG-2026-001_20261014_153000_123456.cli
  CHG-2026-001_20261014_153000_123456.json
```

Para FTD/FMC, a extensão de configuração será `.txt`, não `.cli`. O `.json` guarda os parâmetros preenchidos e pode ser usado para registro, auditoria ou futura integração.

## 7. WARNING — verificação obrigatória antes da mudança

> **ATENÇÃO — SALVAR BASELINE E BACKUP antes da MUDANÇA**
>
> Antes de aplicar qualquer regra, cheque o ambiente, as ACLs/políticas existentes, NAT, roteamento, interfaces e zonas, impactos operacionais, plano de rollback e compatibilidade com o modelo e versão Cisco.

Checklist mínimo:

- [ ] GMUD aprovada e janela de mudança definida.
- [ ] Baseline coletado e armazenado em local seguro.
- [ ] Backup atual da configuração realizado e recuperação verificada.
- [ ] ACLs e políticas existentes analisadas, incluindo ordem e precedência.
- [ ] Origem, destino, porta, protocolo, direção e zonas validados.
- [ ] NAT, VRFs, roteamento e retorno do tráfego verificados.
- [ ] Impacto em sistemas críticos e acesso de gerenciamento avaliado.
- [ ] Plano de rollback documentado e testável.
- [ ] Testes de conectividade, bloqueio e logging definidos.
- [ ] Evidências antes/depois anexadas à GMUD.

O WARNING é mostrado ao fim de cada ciclo, mesmo se os arquivos não forem salvos.

## 8. Solução de problemas

| Sintoma | Causa provável | Ação recomendada |
|---|---|---|
| `python3` não reconhecido | Python ausente ou fora do PATH | Instale Python e tente `py` (Windows). |
| `Campo obrigatório` | Entrada vazia sem padrão | Preencha o campo solicitado. |
| `Opção inválida` | Número fora das opções | Digite o número mostrado no menu. |
| `IPv4 ou CIDR válido` | IP ou máscara incorretos | Use `10.0.0.10` ou `10.0.0.0/24`. |
| `Porta TCP/UDP deve estar entre 1 e 65535` | Porta inválida | Informe uma porta numérica válida. |
| `PermissionError` ao salvar | Sem permissão na pasta atual | Execute em pasta com permissão de escrita. |
| FTD não gera `.cli` | Comportamento intencional | Use a especificação `.txt` no FMC/FDM. |
| ZBFW não gera regra intra-zona | Proteção do assistente | Reavalie o desenho de zonas e a política. |

## 9. Limitações conhecidas

- Suporta **somente IPv4** nesta versão.
- Não realiza descoberta de equipamentos, backup, baseline ou validação do ambiente automaticamente.
- Não confirma suporte por modelo, PID, licença ou versão.
- Não consulta regras existentes e não determina a posição ideal de uma entrada.
- Não faz deploy, rollback ou testes de conectividade.
- Para TCP/UDP, solicita apenas **porta de destino**; não oferece intervalo de portas ou porta de origem.
- Não contempla objetos complexos, aplicações L7, identidades, políticas IPS ou tradução NAT na geração.
- O gerador ZBFW fornece um **modelo que precisa de revisão especializada**; não é um procedimento universal seguro para aplicação direta.
- A função de logging pode variar entre plataformas e versões.

## 10. Boas práticas de operação

Use o script como gerador de rascunhos técnicos, não como mecanismo de autorização. Preserve os arquivos `.json` junto à GMUD, revise as diferenças entre a configuração proposta e a atual, valide em laboratório ou ambiente de homologação e mantenha evidências de pré-mudança, execução, pós-validação e eventual rollback.

**Responsabilidade de implantação:** analista autorizado e processo formal de Change Management da organização.
