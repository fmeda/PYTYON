import ipaddress

def validate_ip_range(ip_range):
    try:
        ipaddress.ip_network(ip_range, strict=False)
        return True
    except ValueError:
        return False

def log(message, level="info"):
    levels = {
        "info": "[*]",
        "error": "[!]",
        "success": "[+]"
    }
    print(f"{levels.get(level, '[*]')} {message}")

def show_help_message():
    print("Uso: python netautoscan.py -r 192.168.1.0/24 [-o csv|pdf] [-i]")
    print("Exemplo: python netautoscan.py -r 192.168.0.0/24 -o csv -i")