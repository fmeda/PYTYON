import argparse
from scanner import Scanner
from utils import log, show_help_message

def main():
    parser = argparse.ArgumentParser(description="NetAutoScan - Scanner de Ativos e Inventário de Rede")
    parser.add_argument("-r", "--range", required=True, help="Intervalo de IPs para escanear (ex: 192.168.0.1/24)")
    parser.add_argument("-o", "--output", choices=["csv", "pdf"], default="csv", help="Formato de saída: csv ou pdf")
    parser.add_argument("-i", "--incremental", action="store_true", help="Ativa modo de inventário incremental")
    args = parser.parse_args()

    if not args.range:
        show_help_message()
        return

    scanner = Scanner(ip_range=args.range, output_format=args.output, incremental=args.incremental)
    scanner.run()

if __name__ == "__main__":
    main()