import nmap
import csv
from utils import validate_ip_range, log
from report import generate_pdf_report
from database import load_previous_results, save_scan_result

class Scanner:
    def __init__(self, ip_range, output_format="csv", incremental=False):
        self.ip_range = ip_range
        self.output_format = output_format
        self.incremental = incremental
        self.scanner = nmap.PortScanner()
        self.previous_results = load_previous_results() if incremental else {}

    def run(self):
        if not validate_ip_range(self.ip_range):
            log("Intervalo de IP inválido.", level="error")
            return

        log(f"Iniciando escaneamento em: {self.ip_range}", level="info")
        self.scanner.scan(hosts=self.ip_range, arguments="-sn")

        results = []
        for host in self.scanner.all_hosts():
            status = self.scanner[host].state()
            mac = self.scanner[host]['addresses'].get('mac', 'N/A')
            vendor = self.scanner[host]['vendor'].get(mac, 'N/A') if mac != 'N/A' else 'N/A'
            os_match = self.scanner[host].get('osmatch', [{}])[0].get('name', 'N/A')

            result = {
                "ip": host,
                "status": status,
                "mac": mac,
                "vendor": vendor,
                "os": os_match
            }
            results.append(result)
            save_scan_result(result, incremental=self.incremental)

        if self.output_format == "csv":
            self.export_csv(results)
        elif self.output_format == "pdf":
            generate_pdf_report(results)

        log("Escaneamento finalizado.", level="info")

    def export_csv(self, results):
        filename = "inventario_ativos.csv"
        with open(filename, mode="w", newline="") as csvfile:
            fieldnames = ["ip", "status", "mac", "vendor", "os"]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in results:
                writer.writerow(row)
        log(f"Inventário exportado para {filename}", level="info")