from fpdf import FPDF

def generate_pdf_report(results):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt="Relatório de Inventário de Ativos", ln=True, align="C")

    pdf.set_font("Arial", size=10)
    for item in results:
        line = f"IP: {item['ip']} | Status: {item['status']} | MAC: {item['mac']} | Vendor: {item['vendor']} | OS: {item['os']}"
        pdf.cell(200, 10, txt=line, ln=True)

    pdf.output("inventario_ativos.pdf")