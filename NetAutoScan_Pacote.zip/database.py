import json
import os

DB_FILE = "inventario_incremental.json"

def load_previous_results():
    if not os.path.exists(DB_FILE):
        return {}
    with open(DB_FILE, "r") as f:
        return json.load(f)

def save_scan_result(result, incremental=False):
    if not incremental:
        return
    data = load_previous_results()
    ip = result["ip"]
    data[ip] = result
    with open(DB_FILE, "w") as f:
        json.dump(data, f, indent=4)