# 📘 Guia Técnico Profissional: SentinelCore-XDR

> Plataforma Modular de Ciberdefesa com SIEM, HIDS, DFIR, Threat Hunting e Resposta a Incidentes.

...

## 🧩 Palavras-chave

```
XDR, SIEM, SOC, DFIR, Threat Intelligence, Compliance, ELK Stack, Cortex, TheHive, Suricata, Zeek, MISP, LGPD, MITRE ATT&CK, Sigma Rules, DevSecOps, Observabilidade, SOAR, STIX/TAXII, Hardening Linux
```
