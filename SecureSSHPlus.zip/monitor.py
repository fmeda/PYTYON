#!/usr/bin/env python3
import psutil, time

def monitor_connections():
    print("[+] Monitorando conexões SSH em tempo real...")
    try:
        while True:
            conns = [c for c in psutil.net_connections() if c.laddr.port == 22]
            for conn in conns:
                print(f"Conexão ativa -> {conn.laddr} -> {conn.raddr}")
            time.sleep(5)
    except KeyboardInterrupt:
        print("\n[!] Monitoramento encerrado.")

if __name__ == "__main__":
    monitor_connections()
