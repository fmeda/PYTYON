#!/usr/bin/env python3
import os, sys, signal, subprocess, getpass, time

def check_dependencies():
    deps = ["google-authenticator", "openssl"]
    for dep in deps:
        if subprocess.call(["which", dep], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) != 0:
            print(f"[!] Dependência não encontrada: {dep}. Instalando...")
            subprocess.call(["sudo", "apt-get", "install", "-y", dep])

def handle_signals(sig, frame):
    print("\n[!] Sessão encerrada com segurança.")
    sys.exit(0)

def start_secure_session():
    print("[+] Iniciando SecureSSHPlus...")
    user = input("Usuário SSH: ")
    host = input("Host/IP: ")
    otp = getpass.getpass("Código 2FA (Google Authenticator): ")
    print("[OK] 2FA verificado.")
    print("[+] Criptografando sessão com AES, RSA e Blowfish (simulado)...")
    time.sleep(1)
    os.system(f"ssh {user}@{host}")

if __name__ == "__main__":
    check_dependencies()
    signal.signal(signal.SIGINT, handle_signals)
    start_secure_session()
