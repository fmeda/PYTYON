#!/bin/bash
echo "[+] Limpando chaves SSH após a sessão..."
rm -f ~/.ssh/known_hosts
rm -f ~/.ssh/id_rsa
echo "[OK] Chaves removidas com segurança."
