# SecureSSHPlus
Solução avançada de segurança para conexões SSH em Linux.

## Recursos
- Autenticação em duas etapas (2FA) via Google Authenticator
- Criptografia tripla (AES, RSA, Blowfish)
- Monitoramento em tempo real de conexões
- Deleção automática de chaves ao fim da sessão
- Tratamento robusto de erros e sinais
- Pré-check de dependências com instalação automática
- CLI intuitiva com --help aprimorado

## Uso
1. Execute `secure_ssh_plus.py` para iniciar uma sessão segura.
2. Use `monitor.py` para acompanhar conexões SSH em tempo real.
3. Rode `cleanup_keys.sh` para limpar chaves após a sessão.
