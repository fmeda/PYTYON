# CompliSense Bot
Bot de análise de conformidade e auditoria.
Executar com Python 3.10 ou superior.
