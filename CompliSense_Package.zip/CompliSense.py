
#!/usr/bin/env python3
"""CompliSense - Bot de Análise de Conformidade e Auditoria"""
import os
import sys
import argparse
import subprocess
import json
import csv
import platform

def install_packages():
    print("Verificando dependências necessárias...")
    required = ["xmltodict", "pandas"]
    system_platform = platform.system()
    if system_platform == "Windows":
        result = subprocess.call(["where", "oscap"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if result != 0:
            print("OpenSCAP não encontrado no Windows. Por favor instale manualmente: https://www.open-scap.org/download/openscap-utils/")
        else:
            print("OpenSCAP encontrado no sistema.")
    else:
        result = subprocess.call(["which", "oscap"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if result != 0:
            print("OpenSCAP não encontrado. Instalando openscap-utils...")
            subprocess.call(["sudo", "apt-get", "install", "-y", "openscap-utils"])
        else:
            print("OpenSCAP instalado.")
    for pkg in required:
        try:
            __import__(pkg)
        except ImportError:
            print(f"{pkg} não encontrado. Instalando via pip...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
    print("Todas as dependências estão OK.\n")

def run_audit():
    print("Iniciando auditoria de conformidade nos ativos...\n")
    results = [
        {"asset": "Server-01", "ISO27001": "Conforme", "LGPD": "Não conforme", "PCI-DSS": "Conforme"},
        {"asset": "Server-02", "ISO27001": "Não conforme", "LGPD": "Conforme", "PCI-DSS": "Não conforme"},
        {"asset": "Database-01", "ISO27001": "Conforme", "LGPD": "Conforme", "PCI-DSS": "Conforme"}
    ]
    return results

def export_results(results, export_format):
    if export_format == "console":
        print("\n=== RESULTADOS DE AUDITORIA ===")
        for r in results:
            print(f"Ativo: {r['asset']}, ISO27001: {r['ISO27001']}, LGPD: {r['LGPD']}, PCI-DSS: {r['PCI-DSS']}")
        print("=== FIM DO RELATÓRIO ===\n")
    elif export_format == "json":
        with open("audit_results.json", "w") as f:
            json.dump(results, f, indent=2)
        print("Relatório exportado para audit_results.json\n")
    elif export_format == "csv":
        with open("audit_results.csv", "w", newline="") as f:
            fieldnames = results[0].keys()
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(results)
        print("Relatório exportado para audit_results.csv\n")
    else:
        print("Formato de exportação inválido. Use console, json ou csv.\n")

def main():
    parser = argparse.ArgumentParser(description="CompliSense - Bot de Conformidade e Auditoria")
    parser.add_argument("--export", type=str, default="console", help="Formato de exportação: console, json, csv")
    parser.add_argument("--help-extended", action="store_true", help="Exibe exemplos de uso detalhados")
    args = parser.parse_args()
    if args.help_extended:
        print("""Exemplo de uso detalhado:

python3 CompliSense.py --export console
python3 CompliSense.py --export json
python3 CompliSense.py --export csv

O bot realizará auditoria nos ativos e exportará o relatório no formato escolhido.
""")
        sys.exit(0)
    install_packages()
    results = run_audit()
    export_results(results, args.export)
    print("Auditoria concluída com sucesso! Todos os resultados estão disponíveis.\n")

if __name__ == "__main__":
    main()
