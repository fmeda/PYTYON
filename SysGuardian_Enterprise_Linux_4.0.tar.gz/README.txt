SysGuardian Enterprise Linux 4.0
Instruções rápidas:
1. Extrair tar.gz em /opt/sysguardian
2. chmod +x nos scripts
3. Executar manualmente ou via cron
4. Verificar logs e relatórios