#!/bin/bash
# Script para execução automática via cron
sudo /opt/sysguardian/sysguardian.sh --all --silent --webhook-url "https://seuwebhook.com"
