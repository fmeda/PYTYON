# Docker Security Scanner PRO

## Requisitos
- Python 3.x
- Docker instalado
- Acesso sudo para instalar ferramentas necessárias

## Instalação de dependências
pip install -r requirements.txt

## Execução do Scanner
python3 docker_security_pro.py

Siga as instruções do menu interativo para:
1. Auditar o host Docker
2. Escanear imagens Docker
3. Escanear containers ativos
4. Obter sugestões de hardening via Dockle
5. Executar todas as auditorias

## Relatórios Gerados
- docker_security_report.csv → resumo CSV
- docker_security_report.json → relatório JSON
- docker_security_report.html → relatório HTML interativo

## Notas
- Use docker login seguro para imagens privadas.
- O scanner verifica pré-requisitos e instala ferramentas ausentes.
- Mensagens coloridas e barra de progresso tornam o uso amigável.
