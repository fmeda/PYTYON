#!/usr/bin/env python3
import argparse
import os
import subprocess

def pre_check():
    print('[*] Checando dependências...')
    packages = ['git', 'python3-venv', 'python3-pip', 'filebeat', 'elasticsearch']
    for pkg in packages:
        result = subprocess.run(['which', pkg], capture_output=True)
        if result.returncode != 0:
            print(f'[!] Pacote {pkg} não encontrado. Instalando...')
            subprocess.run(['sudo', 'apt', 'install', '-y', pkg])

def deploy_honeypot():
    print('[*] Deploy Cowrie Honeypot...')
    if not os.path.exists('honeypot/cowrie'):
        subprocess.run(['git', 'clone', 'https://github.com/cowrie/cowrie.git', 'honeypot/cowrie'])
    os.chdir('honeypot/cowrie')
    subprocess.run(['python3', '-m', 'venv', 'cowrie-env'])
    subprocess.run(['cowrie-env/bin/pip', 'install', '--upgrade', 'pip'])
    subprocess.run(['cowrie-env/bin/pip', 'install', '-r', 'requirements.txt'])
    if not os.path.exists('etc/cowrie.cfg'):
        subprocess.run(['cp', 'etc/cowrie.cfg.dist', 'etc/cowrie.cfg'])
    print('[*] Cowrie configurado. Use "bin/cowrie start" para iniciar manualmente.')

def export_iocs():
    print('[*] Exportando IOCs...')
    subprocess.run(['python3', 'iocs_export/export_iocs.py'])

def setup_grafana_dashboard():
    print('[*] Importando dashboards Grafana...')
    print('[!] Dashboards iniciais preparados em grafana/dashboards')

def main():
    parser = argparse.ArgumentParser(description='HoneySense: Honeypot + Wazuh + Grafana')
    parser.add_argument('--precheck', action='store_true', help='Checa e instala dependências')
    parser.add_argument('--deploy-honeypot', action='store_true', help='Instala e configura Cowrie')
    parser.add_argument('--export-iocs', action='store_true', help='Exporta IOCs coletados')
    parser.add_argument('--setup-grafana', action='store_true', help='Prepara dashboards iniciais Grafana')
    args = parser.parse_args()

    if args.precheck:
        pre_check()
    if args.deploy_honeypot:
        deploy_honeypot()
    if args.export_iocs:
        export_iocs()
    if args.setup_grafana:
        setup_grafana_dashboard()
    if not any(vars(args).values()):
        parser.print_help()

if __name__ == '__main__':
    main()