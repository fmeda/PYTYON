# Cowrie Honeypot
Instruções básicas para deploy.