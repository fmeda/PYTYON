# Rules Wazuh
Regras de alerta para eventos Cowrie.