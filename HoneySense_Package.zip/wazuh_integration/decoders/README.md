# Decoders Wazuh
Decoders customizados para Cowrie.