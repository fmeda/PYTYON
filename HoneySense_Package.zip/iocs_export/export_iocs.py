#!/usr/bin/env python3
import json, csv
from datetime import datetime

log_path = "/var/log/cowrie/cowrie.json"

try:
    with open(log_path) as f:
        logs = [json.loads(line) for line in f]
except FileNotFoundError:
    print("[!] Arquivo de log não encontrado:", log_path)
    exit(1)

ioc_list = []
for log in logs:
    if log.get("eventid") in ["cowrie.login.failed", "cowrie.session.closed"]:
        ioc_list.append({
            "ip": log.get("src_ip"),
            "timestamp": log.get("timestamp"),
            "username": log.get("username"),
            "password": log.get("password"),
        })

if ioc_list:
    filename = f"iocs_{datetime.now().strftime('%Y%m%d')}.csv"
    with open(filename, "w") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=ioc_list[0].keys())
        writer.writeheader()
        writer.writerows(ioc_list)
    print(f"[*] IOCs exportados para {filename}")
else:
    print("[*] Nenhum IOC encontrado")