# HoneySense
Pacote completo Honeypot + Wazuh + Grafana, pronto para SOC/SIEM.