#!/usr/bin/env python3
import subprocess
packages = ['git', 'python3-venv', 'python3-pip', 'filebeat', 'elasticsearch']
for pkg in packages:
    result = subprocess.run(['which', pkg], capture_output=True)
    if result.returncode != 0:
        print(f'Instalando {pkg}...')
        subprocess.run(['sudo', 'apt', 'install', '-y', pkg])
print('Dependências instaladas.')