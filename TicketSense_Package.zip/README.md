# TicketSense - Bot de Análise de Sentimento em Tickets SOC/NOC

## Descrição
Bot para priorização de tickets com análise de sentimento e exportação.

## Uso
python ticketsense_prod.py --platform glpi --api_url <URL> --token <TOKEN> --export console

Formatos de exportação: console, json, csv
