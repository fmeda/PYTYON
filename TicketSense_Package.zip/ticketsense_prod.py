# Script TicketSense completo fornecido pelo usuário
