# TPM/Enclave Integrity Check (Simulado com extensão real futura)
import subprocess

def verify_hardware_integrity():
    try:
        output = subprocess.check_output(["tpm2_getrandom", "4"])
        return True if output else False
    except:
        return False

def execute_secure_task(task):
    if not verify_hardware_integrity():
        raise Exception("Tampering Detected")
    return task.run_in_enclave()
