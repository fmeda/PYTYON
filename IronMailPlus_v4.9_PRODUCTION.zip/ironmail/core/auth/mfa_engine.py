# MFA Engine for Production Use
import pyotp
import subprocess

def validate_totp(user):
    totp = pyotp.TOTP(user.get("totp_secret"))
    return totp.verify(user.get("provided_totp"))

def validate_yubikey(user):
    try:
        output = subprocess.check_output(['ykman', 'info'])
        return b'Connected' in output
    except:
        return False

def validate_biometrics(user, context):
    return context.get("biometric_auth") == "PASS"

def validate_mfa(user, method, context):
    if method == "TOTP":
        return validate_totp(user)
    elif method == "YubiKey":
        return validate_yubikey(user)
    elif method == "Biometric":
        return validate_biometrics(user, context)
    return False
