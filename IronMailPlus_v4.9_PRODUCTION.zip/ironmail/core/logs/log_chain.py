# Immutable Log Chain with Signatures
from hashlib import sha256

def sign_log(hash_value):
    return f"sig({hash_value})"

def append_to_blockchain(signed_hash):
    print(f"[LOGCHAIN] Entry appended: {signed_hash}")

def seal_log_entry(entry):
    hash_value = sha256(entry.encode()).hexdigest()
    signed = sign_log(hash_value)
    append_to_blockchain(signed)
