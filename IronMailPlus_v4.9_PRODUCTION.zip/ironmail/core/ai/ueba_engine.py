# UEBA Module with DummyModel
from joblib import load

def load_trained_model():
    class DummyModel:
        def predict(self, entry): return "anomaly" if "suspicious" in entry else "normal"
    return DummyModel()

def alert(entry):
    print(f"[UEBA ALERT] Anomaly detected: {entry}")

def detect_anomalies(log_stream):
    model = load_trained_model()
    for entry in log_stream:
        if model.predict(entry) == "anomaly":
            alert(entry)
