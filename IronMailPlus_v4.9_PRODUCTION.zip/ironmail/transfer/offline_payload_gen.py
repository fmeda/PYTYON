# ASN.1 Payload Generator for Air-Gap Use
def asn1_encode(data, metadata):
    return f"ASN1[{data}|{metadata}]"

def sign(payload):
    return f"SIGN({payload})"

def encrypt_payload(payload):
    return f"ENC({payload})"

def generate_payload(data, metadata):
    encapsulated = asn1_encode(data, metadata)
    signed = sign(encapsulated)
    return encrypt_payload(signed)
